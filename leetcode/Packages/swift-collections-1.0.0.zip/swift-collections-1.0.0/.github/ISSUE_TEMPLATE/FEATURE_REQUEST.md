---
name: 💡 Feature Request
about: A suggestion for a new feature
labels: enhancement
---

<!--
    Thanks for contributing to Swift Collections!

    Before you submit your issue, please replace the paragraph
    below with information about your proposed feature.
-->

Replace this paragraph with a description of your proposed feature. 
Please be sure to describe some concrete use cases for the new feature -- be as specific as possible.
Provide links to existing issues or external references/discussions, if appropriate.
